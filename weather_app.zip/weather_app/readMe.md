# Weather-Journal App Project

 Create an asynchronous web app that uses Web API and user data to dynamically update the UI.

# The lanuages used

- html
- css
- javascript
